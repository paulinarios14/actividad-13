// Objeto Libro
const Libro = {
    titulo: "",
    autor: "",
    anioPublicacion: 0,
    genero: "",
    resumen: function() {
      console.log(`"${this.titulo}" escrito por ${this.autor}, publicado en ${this.anioPublicacion}.`);
    }
  };
  
  // Array de libros (biblioteca)
  const biblioteca = [
    { titulo: "Libro 1", autor: "Autor 1", anioPublicacion: 2000, genero: "Género 1" },
    { titulo: "Libro 2", autor: "Autor 2", anioPublicacion: 2010, genero: "Género 2" },
    { titulo: "Libro 3", autor: "Autor 1", anioPublicacion: 2020, genero: "Género 3" },
    // ... más libros
  ];
  
  // Listar Todos los Libros
  console.log("Detalles de cada libro:");
  biblioteca.forEach(libro => {
    console.log(`Título: ${libro.titulo}, Autor: ${libro.autor}, Año de Publicación: ${libro.anioPublicacion}, Género: ${libro.genero}`);
  });
  
  // Buscar Libros por Autor
  function librosPorAutor(autor) {
    return biblioteca.filter(libro => libro.autor === autor);
  }
  
  const librosAutor1 = librosPorAutor("Autor 1");
  console.log("Libros escritos por Autor 1:", librosAutor1);
  
  // Encontrar el Libro Más Antiguo
  const libroMasAntiguo = biblioteca.reduce((libroAntiguo, libroActual) => {
    return libroActual.anioPublicacion < libroAntiguo.anioPublicacion ? libroActual : libroAntiguo;
  }, biblioteca[0]);
  
  console.log("Libro más antiguo:", libroMasAntiguo);
  
  // Añadir un Método a un Objeto
  Libro.resumen();  // Imprimirá un resumen del libro con los valores predeterminados.
  
  // Puedes asignar valores a las propiedades y luego llamar al método.
  Libro.titulo = "Libro de Ejemplo";
  Libro.autor = "Autor de Ejemplo";
  Libro.anioPublicacion = 2022;
  Libro.genero = "Género de Ejemplo";
  Libro.resumen();  // Imprimirá el resumen con los valores asignados.
  
  // Mostrar Información con Object.keys y Object.values
  function mostrarInfoKeys(obj) {
    const keys = Object.keys(obj);
    console.log("Propiedades del libro:", keys.join(", "));
  }
  
  function mostrarInfoValues(obj) {
    const values = Object.values(obj);
    console.log("Valores del libro:", values.join(", "));
  }
  
  // Ejemplo de uso con el primer libro en la biblioteca
  mostrarInfoKeys(biblioteca[0]);
  mostrarInfoValues(biblioteca[0]);
  