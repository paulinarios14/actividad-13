// Contenido de script.js

// 1. Función para aplicar descuentos
function aplicarDescuento(precioTotalHelados) {
    if (precioTotalHelados > 5) {
      return precioTotalHelados * 0.9; // Aplicar descuento del 10%
    } else {
      return precioTotalHelados;
    }
  }
  
  // 2. Reescribir funciones como funciones flecha
  const calcularPrecio = (cantidadHelados, precioHelado) => cantidadHelados * precioHelado;
  const aplicarDescuentoArrow = precioTotalHelados => (precioTotalHelados > 5 ? precioTotalHelados * 0.9 : precioTotalHelados);
  
  // 3. Función para personalizar helados
  const personalizarHelado = sabor => {
    console.log("Creando un helado de " + sabor);
  };
  
  // 4. Función para saludar
  function saludarCliente() {
    console.log("¡Bienvenido! Esperamos que disfrutes tus helados.");
  }
  
  // 5. Función precio final
  function precioFinal(cantidadHelados, precioHelado) {
    const precioTotal = aplicarDescuentoArrow(calcularPrecio(cantidadHelados, precioHelado));
    saludarCliente();
    console.log("Hola, bienvenido, el total de su compra fue: " + precioTotal);
  }
  